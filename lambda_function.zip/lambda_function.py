import boto3
import json

def lambda_handler(event,context):
    try:
        print('event is '+str(event['queryStringParameters']['params']))
        cust_to_check = str(event['queryStringParameters']['params'])
        print(cust_to_check+'this is parmater being passed')
        dynamodb = boto3.client('dynamodb')
        out_values = dynamodb.get_item(TableName='assesment_customer_match', Key={'customer':{'S':cust_to_check}})
        out_values = out_values['Item']['matching_customers']['S']
        to_return= {
            "isBase64Encoded": False,
             "headers": { 'Content-Type': 'text/html; charset=utf-8'},
            "body": str(out_values),
             "statusCode": 200

            }
        return to_return

    except Exception as e:
        print(e)
        return('oops!!! error occured while getting matching customer , please check input customer id is correct')
        raise e
